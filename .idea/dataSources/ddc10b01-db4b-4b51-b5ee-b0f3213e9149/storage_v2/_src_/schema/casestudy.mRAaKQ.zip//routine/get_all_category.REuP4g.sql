create
    definer = root@localhost procedure get_all_category()
BEGIN
    select *
        FROM category;
END;

