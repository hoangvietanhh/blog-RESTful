create
    definer = root@localhost procedure get_all_orderdetail()
begin
   select * from orderdetail;
end;

